from distutils.core import setup

setup(
    name='AA',
    version='1.0',
    py_modules=['AbandonedAnimals','foliumTest','TelegramBot'],
    author='LYJSY',
)
